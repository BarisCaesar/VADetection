import csv, os
import numpy as np
import tensorflow as tf
from tensorflow import keras
from dataset import txt_to_numpy
from sklearn.metrics import confusion_matrix
import tensorflow_model_optimization as tfmot


def save_model(path, save_name, model):
    os.makedirs(path, exist_ok=True)
    save_path = os.path.join(path, f"{save_name}.tflite")
    converter = tf.lite.TFLiteConverter.from_keras_model(model)
    tflite_model = converter.convert()
    with open(save_path, 'wb') as f:
        f.write(tflite_model)
    print(f"Model saved as {save_path}")


def quantize_dynamic(path, save_name,model):
    os.makedirs(path, exist_ok=True)
    path = os.path.join(path, f"{save_name}_quant.tflite")
    converter = tf.lite.TFLiteConverter.from_keras_model(model)
    converter.optimizations = [tf.lite.Optimize.DEFAULT]
    quant_model = converter.convert()
    with open(path, 'wb') as f:
        f.write(quant_model)
    print(f"Quantized Model saved as {path}")
    return quant_model

# def prepare_qat(model):
#     quantize_model = tfmot.quantization.keras.quantize_model
#     quant_model = quantize_model(model)
#     return quant_model
    
def save_stats(save_name, train_loss, train_acc, test_loss, test_acc, extra_name=None):
    stats_path = os.path.join(os.getcwd(), "stats", save_name)    
    os.makedirs(stats_path, exist_ok=True)
    curr_stat_path = os.path.join(stats_path, f"{save_name}.txt")
    if extra_name:
        curr_stat_path = os.path.join(stats_path, f"{save_name}_{extra_name}.txt")
    
    file = open(curr_stat_path, 'w')
    file.write("Train_loss\n" + str(train_loss) + "\n\n")
    file.write("Train_acc\n" + str(train_acc) + "\n\n")
    file.write("Test_loss\n" + str(test_loss) + "\n\n")
    file.write("Test_acc\n" + str(test_acc) + "\n\n")
    
def save_scores(save_name, scores, extra_name=None):
    stats_path = os.path.join(os.getcwd(), "stats", save_name)    
    os.makedirs(stats_path, exist_ok=True)
    file_name = f"{save_name}_scores.txt"
    if extra_name:
        file_name = f"{save_name}_{extra_name}_scores.txt"
    curr_stat_path = os.path.join(stats_path, file_name)

# challenge_partial_score, confusion_matrix_scores, F_beta_score, g_score, acc, precision,
# sensitivity, FP_rate, PPV, NPV, F1_score

    file = open(curr_stat_path, 'w')
    file.write("partial_score, " + str(scores[0]) + "\n")
    # file.write("cm_scores, " + str(scores[1]) + "\n")
    file.write("f_beta, " + str(scores[2]) + "\n")
    file.write("g_score," + str(scores[3]) + "\n")
    file.write("acc, " + str(scores[4]) + "\n")
    file.write("precision, " + str(scores[5]) + "\n")
    file.write("sensitivity, " + str(scores[6]) + "\n")
    file.write("fp_rate, " + str(scores[7]) + "\n")
    file.write("ppv, " + str(scores[8]) + "\n")
    file.write("npv, " + str(scores[9]) + "\n")
    file.write("f1_score, " + str(scores[10]) + "\n")
    
    
    
def score_report (C):
    if C.shape == (2, 2):
        acc = (C[0][0] + C[1][1]) / (C[0][0] + C[0][1] + C[1][0] + C[1][1])

    if (C[1][1] + C[0][1]) != 0:
        precision = C[1][1] / (C[1][1] + C[0][1])
    else:
        precision = 0.0

    if (C[1][1] + C[1][0]) != 0:
        sensitivity = C[1][1] / (C[1][1] + C[1][0])
    else:
        sensitivity = 1.0

    FP_rate = C[0][1] / (C[0][1] + C[0][0])

    if (C[1][1] + C[1][0]) != 0:
        PPV = C[1][1] / (C[1][1] + C[1][0])
    else:
        PPV = 0.0

    NPV = C[0][0] / (C[0][0] + C[0][1])

    if (precision + sensitivity) != 0:
        F1_score = (2 * precision * sensitivity) / (precision + sensitivity)
    else:
        F1_score = 0.0

    if ((2 ** 2) * precision + sensitivity) != 0:
        F_beta_score = (1 + 2 ** 2) * (precision * sensitivity) / ((2 ** 2) * precision + sensitivity)
    else:
        F_beta_score = 0.0
    return acc, precision, sensitivity, FP_rate, PPV, NPV, F1_score, F_beta_score


def evaluate_model(model, data_path, indices_path, print_debug=False):
    subject_data = {}
    all_metrics = []
    subjects_above_threshold = 0
    with open(indices_path+'test_indice.csv', 'r') as indice_file:
        for line in indice_file:
            label, filename = line.strip().split(',')
            subject_id = filename.split('-')[0]
            if subject_id not in subject_data:
                subject_data[subject_id] = []
            subject_data[subject_id].append((filename, label))
    confusion_matrix_scores = np.zeros(((len(subject_data.items())-1),2,2))

    #Getting subject names to evaluate per subject_id
    for subject_idx, (subject_id, file_info_list) in enumerate(subject_data.items(), start=1):
        if subject_id == 'Filename':
            continue
        y_true_subject = []
        if (print_debug): 
            print(f"Processing subject {subject_id}")
        testX_for_this_subject = np.zeros((len(file_info_list),1250))
        for i in range(len(file_info_list)):
            filename, true_label = file_info_list[i]
            y_true_subject.append(true_label)
            testX_for_this_subject[i,:] = txt_to_numpy(data_path + filename, 1250)
        testX_for_this_subject = testX_for_this_subject[...,::2]
        testX_for_this_subject =  np.expand_dims(testX_for_this_subject, axis=2)
        y_pred_subject = model.predict(testX_for_this_subject).argmax(axis=1)  
        
        # Perform calculations for each participant
        confusion_matrix_for_this_subject = confusion_matrix( np.array(y_true_subject, dtype=int), y_pred_subject)
        confusion_matrix_scores[subject_idx-2] = confusion_matrix_for_this_subject
        if (print_debug):
            print( confusion_matrix_scores[subject_idx-2] )
                
        acc, precision, sensitivity, FP_rate, PPV, NPV, F1_score, F_beta_score = score_report(confusion_matrix_for_this_subject)
        all_metrics.append([acc, precision, sensitivity, FP_rate, PPV, NPV, F1_score, F_beta_score])
        if F_beta_score > 0.95:
            subjects_above_threshold += 1
    subject_metrics_array = np.array(all_metrics)
    average_metrics = np.mean(subject_metrics_array, axis=0)
    acc, precision, sensitivity, FP_rate, PPV, NPV, F1_score, F_beta_score = average_metrics
    
    print("Final F_beta_score:", F_beta_score)
    proportion_above_threshold = subjects_above_threshold / len(all_metrics)
    g_score = proportion_above_threshold
    print("G Score:", g_score)

    challenge_partial_score = 70*F_beta_score + 30*g_score
    return challenge_partial_score, confusion_matrix_scores, F_beta_score, g_score, acc, precision, sensitivity, FP_rate, PPV, NPV, F1_score

def eval_quant_model(model_path, data_path, indices_path, print_debug=False):
    interpreter = tf.lite.Interpreter(model_path=model_path)
    
    input_details = interpreter.get_input_details()
    output_details = interpreter.get_output_details()
    
    subject_data = {}
    all_metrics = []
    subjects_above_threshold = 0
    with open(indices_path+'test_indice.csv', 'r') as indice_file:
        for line in indice_file:
            label, filename = line.strip().split(',')
            subject_id = filename.split('-')[0]
            if subject_id not in subject_data:
                subject_data[subject_id] = []
            subject_data[subject_id].append((filename, label))
    confusion_matrix_scores = np.zeros (((len(subject_data.items())-1),2,2))

    for subject_idx, (subject_id, file_info_list) in enumerate(subject_data.items(), start=1):
        if subject_id == 'Filename':
            continue
        y_true = []
        if (print_debug): 
            print(f"Processing subject {subject_id}")
        x_test = np.zeros((len(file_info_list),1250))
        for i in range(len(file_info_list)):
            filename, true_label = file_info_list[i]
            y_true.append(true_label)
            x_test[i,:] = txt_to_numpy(data_path + filename, 1250)
        x_test = x_test[...,::2]
        x_test =  np.expand_dims(x_test, axis=2)
        x_test = np.array(x_test, dtype=np.float32)
        y_true = np.array(y_true, dtype=int)
        
        interpreter.resize_tensor_input(input_details[0]["index"], x_test.shape)
        interpreter.resize_tensor_input(output_details[0]["index"], y_true.shape)
        
        input_details = interpreter.get_input_details()
        output_details = interpreter.get_output_details()
        interpreter.allocate_tensors()
        interpreter.set_tensor(input_details[0]["index"], x_test)
        interpreter.invoke()
        y_pred = interpreter.get_tensor(output_details[0]["index"]).argmax(axis=1)

        confusion_matrix_for_this_subject = confusion_matrix( np.array(y_true, dtype=int), y_pred)
        confusion_matrix_scores[subject_idx-2] = confusion_matrix_for_this_subject
        if (print_debug):
            print( confusion_matrix_scores[subject_idx-2] )
                
        acc, precision, sensitivity, FP_rate, PPV, NPV, F1_score, F_beta_score = score_report(confusion_matrix_for_this_subject)
        all_metrics.append([acc, precision, sensitivity, FP_rate, PPV, NPV, F1_score, F_beta_score])
        if F_beta_score > 0.95:
            subjects_above_threshold += 1
    subject_metrics_array = np.array(all_metrics)
    average_metrics = np.mean(subject_metrics_array, axis=0)
    acc, precision, sensitivity, FP_rate, PPV, NPV, F1_score, F_beta_score = average_metrics
    
    print("Final F_beta_score:", F_beta_score)
    proportion_above_threshold = subjects_above_threshold / len(all_metrics)
    g_score = proportion_above_threshold
    print("G Score:", g_score)

    challenge_partial_score = 70*F_beta_score + 30*g_score
    return challenge_partial_score, confusion_matrix_scores, F_beta_score, g_score, acc, precision, sensitivity, FP_rate, PPV, NPV, F1_score
 