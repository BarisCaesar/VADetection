from tensorflow import keras

def get_model(dropout_rate=0.0):
    model = keras.Sequential([
        keras.layers.Input(shape=(625, 1)),

        keras.layers.Conv1D(filters=2, kernel_size=5, strides=2, padding='valid', activation=None, use_bias=False),
        keras.layers.BatchNormalization(axis=-1, momentum=0.1, epsilon=1e-5, center=True, scale=True,
                                        trainable=True),
        keras.layers.ReLU(),

        keras.layers.Conv1D(filters=4, kernel_size=5, strides=2, padding='valid', activation=None, use_bias=False),
        keras.layers.BatchNormalization(axis=-1, momentum=0.1, epsilon=1e-5, center=True, scale=True,
                                        trainable=True),
        keras.layers.ReLU(),

        keras.layers.Conv1D(filters=6, kernel_size=4, strides=2, padding='valid', activation=None, use_bias=False),
        keras.layers.BatchNormalization(axis=-1, momentum=0.1, epsilon=1e-5, center=True, scale=True,
                                        trainable=True),
        keras.layers.ReLU(),

        keras.layers.Flatten(),
        keras.layers.Dropout(dropout_rate),
        keras.layers.Dense(8, kernel_regularizer=keras.regularizers.l2(0.01)),
        keras.layers.ReLU(),
        keras.layers.Dense(2, kernel_regularizer=keras.regularizers.l2(0.01)),
    ])
    return model
