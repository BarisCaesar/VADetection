import csv, os
import numpy as np
import tensorflow as tf

def txt_to_numpy(filename, row):
    file = open(filename)
    lines = file.readlines()
    datamat = np.arange(row, dtype=np.float64)
    row_count = 0
    for line in lines:
        line = line.strip().split(' ')
        datamat[row_count] = line[0]
        row_count += 1

    return datamat

def loadCSV(csvf):
    dictLabels = {}
    with open(csvf) as csvfile:
        csvreader = csv.reader(csvfile, delimiter=',')
        next(csvreader, None)  # skip (filename, label)
        for i, row in enumerate(csvreader):
            filename = row[0]
            label = row[1]

            # append filename to current label
            if label in dictLabels.keys():
                dictLabels[label].append(filename)
            else:
                dictLabels[label] = [filename]
    return dictLabels

    
class DataGenerator(tf.keras.utils.Sequence):
  def __init__(self, root_dir, indice_dir, mode, size, subject_id=None):
        self.root_dir = root_dir
        self.indice_dir = indice_dir
        self.size = size
        self.names_list = []

        #csvdata_all = loadCSV(os.path.join(self.indice_dir, mode + '_indice.csv'))
        csvdata_all = loadCSV(self.indice_dir + "/" + mode + '_indice.csv')

        for i, (k, v) in enumerate(csvdata_all.items()):
            # Check if the subject ID matches
            if subject_id is not None and k.startswith(subject_id):
                self.names_list.extend([f"{k} {filename}" for filename in v])
            elif subject_id is None:
                self.names_list.append(str(k) + ' ' + str(v[0]))

  def __len__(self):
    return len(self.names_list)

  def __getitem__(self, idx):
    text_path = self.root_dir + self.names_list[idx].split(' ')[0]

    if not os.path.isfile(text_path):
      print(text_path + 'does not exist')
      return None

    IEGM_seg = txt_to_numpy(text_path, self.size).reshape(1, self.size, 1)
    label = int(self.names_list[idx].split(' ')[1])
    sample = np.append(IEGM_seg, label)  #Giving the sample in this format instead of a dict as in IEGM_DataSET
    # sample = {'IEGM_seg': IEGM_seg, 'label': label}
    return sample