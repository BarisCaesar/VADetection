import os
os.environ['TF_ENABLE_ONEDNN_OPTS'] = '0'
import argparse
import random
import datetime
import numpy as np

import tensorflow as tf
from tensorflow import keras

from utils import (
    save_model,
    quantize_dynamic,
    save_stats,
    evaluate_model,
    eval_quant_model,
    save_scores)
from model import get_model
from dataset import DataGenerator
from augmentations import apply_aug


def train_validation(path_data, path_indices, SIZE):
    train_generator = DataGenerator(root_dir=path_data, indice_dir=path_indices, mode='train', size=SIZE)
    train_dataset = tf.data.Dataset.from_tensor_slices(train_generator)
    train_dataset = train_dataset.shuffle(10).batch(len(train_generator))
    train_dataset = train_dataset.repeat()
    train_iterator = iter(train_dataset)

    test_generator = DataGenerator(root_dir=path_data, indice_dir=path_indices, mode='test', size=SIZE)
    test_dataset = tf.data.Dataset.from_tensor_slices(test_generator)
    test_dataset = test_dataset.shuffle(10).batch(len(test_generator))
    test_dataset = test_dataset.repeat()
    test_iterator = iter(test_dataset)

    train_samples = train_iterator.get_next()
    x, y = train_samples[...,:-1:2], train_samples[...,-1]
    x = np.expand_dims(x, axis=2)
    
    test_samples = test_iterator.get_next()
    x_test, y_test = test_samples[...,:-1:2], test_samples[...,-1]
    x_test = np.expand_dims(x_test, axis=2)
    
    x_aug = np.copy(x)
    y_aug = np.copy(y)
    x_aug = apply_aug(x_aug, True)
    x = np.concatenate((x, x_aug))
    y = np.concatenate((y, y_aug))
    
    net = get_model(dropout_rate=0.5)    
    save_name = "baseline_deneme"
    # model.{epoch: 02d} - {val_loss: .4f}.h5
    checkpt_name = f"{save_name}.weights.h5"
    checkpoint_path = os.path.join("checkpoints", checkpt_name)

    model_checkpoint_callback = tf.keras.callbacks.ModelCheckpoint(
        filepath=checkpoint_path,
        save_weights_only=True,
        monitor='val_loss',
        mode='min',
        save_best_only=True
    )
    
    history_callback = tf.keras.callbacks.History()
    
    net.compile(
        optimizer=keras.optimizers.Adam(learning_rate=args.lr),
        loss=tf.keras.losses.SparseCategoricalCrossentropy(from_logits=True),
        metrics=['accuracy']
    )
    
    net.fit(
        x,
        y,
        epochs=args.epoch,
        batch_size=args.batchsz,
        shuffle=True,
        validation_data=(x_test, y_test),
        callbacks=[history_callback, model_checkpoint_callback]
    )
    
    save_stats(
        save_name,
        history_callback.history['loss'],
        history_callback.history['accuracy'],
        history_callback.history['val_loss'],
        history_callback.history['val_accuracy']
    )

    net.load_weights(checkpoint_path)
    score = net.evaluate(x_test, y_test)
    print(f"Model: {save_name}, loss: {score[0]}, acc: {score[1]}")
    
    save_model(f'./out_models/{save_name}', save_name, net)
    quantize_dynamic(f'./out_models/{save_name}', save_name, net)
    
    scores = evaluate_model(net, path_data, path_indices+'/')
    quant_scores = eval_quant_model(f"./out_models/{save_name}/{save_name}_quant.tflite", path_data, path_indices+'/')
    
    save_scores(save_name, scores)
    save_scores(save_name, quant_scores, "quant")
    return scores, quant_scores
          
def main():
    SIZE = args.size
    path_data = args.path_data
    path_indices = args.path_indices
    
    scores, quant_scores = train_validation(path_data, path_indices, SIZE)
    print(f"Final Model: FBeta {scores[2]} and G {scores[3]} found! Score: {scores[0]}")
    print(f"Quantized: FBeta {quant_scores[2]} and G {quant_scores[3]} found! Score: {quant_scores[0]}")

     
if __name__ == '__main__':
    argparser = argparse.ArgumentParser()
    argparser.add_argument('--epoch', type=int, help='epoch number', default=2)
    argparser.add_argument('--lr', type=float, help='learning rate', default=0.0002)
    argparser.add_argument('--batchsz', type=int, help='total batchsz for traindb', default=32)
    argparser.add_argument('--cuda', type=int, default=0)
    argparser.add_argument('--size', type=int, default=1250)
    argparser.add_argument('--path_data', type=str, default='./train_data/')
    argparser.add_argument('--path_indices', type=str, default='./data_indices')

    args = argparser.parse_args()

    main()


    # qat_model = prepare_qat(net)
    # qat_model.compile(
    #     optimizer=Adam(learning_rate=args.lr),
    #     loss=tf.keras.losses.SparseCategoricalCrossentropy(from_logits=True),
    #     metrics=['accuracy']
    # )
    # qat_model.fit(
    #     x,y,
    #     epochs=args.epoch,
    #     batch_size=args.batchsz,
    #     shuffle=True,
    #     validation_data=(x_test, y_test),
    #     callbacks=[model_checkpoint_callback, history_callback]
    # )
    # converter = tf.lite.TFLiteConverter.from_keras_model(qat_model)
    # converter.optimizations = [tf.lite.Optimize.DEFAULT]

    # quantized_tflite_model = converter.convert()
    # with open(f'./out_models/{save_name}', 'wb') as f:
    #     f.write(quantized_tflite_model)