from scipy.signal import resample
import numpy as np
import random

def stretch(x):
    x_stretched = np.zeros(x.shape)
    stretch = (random.random()/4)+0.05
    l = int(625 * (1 + stretch))
    resampled_x = resample(x[:], l)
    if (l < 625):
        resampled_x_ = np.zeros(shape=(625, ))
        resampled_x_[:l] = resampled_x
    else:
        resampled_x_ = resampled_x[:625]
    x_stretched = resampled_x_
    return x_stretched

def scale(x):
    x_scaled = np.zeros(x.shape)
    alpha = (random.random()-0.5)/4 
    x_scaled = x*(1+alpha)
    return x_scaled

def add_noise(x):
    scale  = x.max() * random.random() * 0.05
    noise = np.random.normal(0, scale, (len(x), 1))
    x_with_added_noise = x + noise
    return x_with_added_noise

def apply_aug(x_aug, noise_active=True):
    stretch_or_not = random.random()
    scale_or_not = random.random()
    for i in range(len(x_aug)):
        if stretch_or_not > 0.5:
            x_aug[i] = stretch(x_aug[i])
        if scale_or_not > 0.5:
            x_aug[i] = scale(x_aug[i])
        if noise_active:
            x_aug[i] = add_noise(x_aug[i])
    return x_aug